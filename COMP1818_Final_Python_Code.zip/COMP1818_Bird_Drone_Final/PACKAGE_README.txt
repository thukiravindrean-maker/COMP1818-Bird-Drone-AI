COMP1818 — FINAL PYTHON PROJECT PACKAGE

This ZIP contains the Python source/config files and existing supporting results in the project folder.
It deliberately excludes the AOD-4 dataset, virtual environment, raw videos and temporary outputs.
Original code and evidence were copied without alteration. Check this package before submission.

QUICK START (on Windows, from extracted project directory):
  python -m venv .venv
  .\.venv\Scripts\Activate.ps1
  python -m pip install -r requirements.txt
  python dashboard.py

DATASET:
  The AOD-4 dataset is NOT bundled. Install it separately and adjust data.yaml
  to point to the correct local location, ensuring images/test and labels/test align.
  Do not use evaluation-only data.yaml to retrain the detector.

MODEL CHECKPOINTS:
  models/best_10epochs.pt and models/best_50epochs.pt are included only if
  both exist. Check the contents of PACKAGE_REVIEW.txt for missing files.

RESEARCH CAUTIONS:
  Track IDs are not verified physical object counts; no independent tracking
  ground truth is included. Check 10/50 epoch provenance and test-set independence.
  Figures in the report should be originals generated programmatically, not screenshots.

FINAL SUBMISSION:
  Check the official Moodle rules, file-size limit, code URL, and LO3 requirements.
  The final LaTeX PDF is not automatically included unless already stored in
  a report/ or figures/ folder inside your local project.
